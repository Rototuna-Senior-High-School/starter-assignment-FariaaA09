import random
#Welcome Message
print('Welcome to Doctors Without Borders!')
print('You can play with a maximum of $10 and a minimum of $1.')
input('Press ENTER to start')

#Tokens
tokens = ["horse", "zebra", "donkey", "unicorn"]

#Inserting Money
balance = float(input("How much money would you like to play with? "))
if balance > 10 or balance <= 0:
    print('Please enter an amount between 1 and 10')
else:
    print(f"You have chosen to play with ${int(balance)}.")
#Quit or play 1
    while balance >= 1: 
        play = input('Type C to continue or Q to cashout:').lower()
        
        if play == "q":
            print(f'Cashout successful. You ended with ${balance:.2f}. Thanks for playing!')
            break
        
        elif play == 'c':  
#Printing Random Token
            chosen = random.choice(tokens)
            print(f'You have received a {chosen}.')
            
#Deduct money
            balance -= 1 
            print(f'You paid $1 to play. Your new balance is ${balance:.2f}')
            
#Winnings
            if chosen == "unicorn":
                balance += 5
                print("You won $5!")
            elif chosen in ["horse", "zebra"]:
                balance += 0.5
                print("You won 50 cents!")
                
            print(f'Your updated balance is ${balance:.2f}')
        
        else:
            print("Invalid answer. Please type CONTINUE or QUIT.")
    
#If the player runs out of money, end the game
    if balance < 1:
        print("You have run out of money. Game over!")



